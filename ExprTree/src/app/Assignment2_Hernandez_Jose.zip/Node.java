package app;
//using a node class for the left and right nodes
public class Node {
    
    public String value;
    public Node left;
    public Node right;
    public boolean isOperator;

    public Node(String val){
        value = val; 
    }
    
}
