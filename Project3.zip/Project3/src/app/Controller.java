/*
Progammer: Jose R Hernandez
Panther ID: 1398700

Class: COP3337 - Computer Programming II
Section: U01
Semester: Summer 2020
Classtime: Online

Project: Project 3
due: July 12, 2020

CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my 
               own and that none of it is the work of any other person.
*/
package app;

public class Controller {


    public static void main(String[] args) {
       
       int [] answer = {1, 1, 2, 15, 131, 1160, 10279, 91089, 807202, 7153171, 
           63389159, 561734856, 682950907, 1163077693, 71344026, -1886883273,
           2095387611, -872152760, -1876028609, 1271956537}; 
       
       int [] result = new int[20];
       int [] endResult = new int[20];
       
       int X = 0;
       int Y = 0;
       int Z = 0;
       
        
       System.out.println("==================================================");
       System.out.println("============== GROUP 4 SEQUENCE ==================");
       System.out.println("==================================================");
       System.out.println("");
       
       for(int x = -10; x<=10; x++){
           for(int y = -10; y<=10; y++){
               for(int z = -10; z<=10; z++){
                   for(int n = 1; n<=20; n++){
                       result[n-1] = fib(n,x,y,z);
                       if(result[n-1] == answer[n-1]){
                           if(result[n-1] != endResult[n-1]){
                               endResult[n-1] = result[n-1];
                               X = x;
                               Y = y;
                               Z = z;                               
                           }                      
                       }
                   }                   
               }
           }
       }
       
       for(int k =0; k < endResult.length; k++){
           if(k !=19){
               System.out.print(endResult[k] + ", ");               
           }
           else{
               System.out.println(endResult[k]);
           }        
       }       
       System.out.println("\n");
       System.out.println("==================================================");
       System.out.println("============= MULTIPLIERS X, Y, & Z ==============");
       System.out.println("==================================================");
       System.out.println("");
       
       System.out.println("X:  " + X);
       System.out.println("Y: " + Y);
       System.out.println("Z: " + Z);
    }
    

    public static int fib(int n, int x, int y, int z){
        if(n == 1) return 1;
        if(n == 2) return 1;
        if(n == 3) return 2;
        return x*fib(n-1, x, y, z) + y*fib(n-2, x, y, z) + z*fib(n-3, x, y, z);
    }   
}