
package reports;

import java.util.ArrayList;
import java.util.Map;

public class FinancialReport extends PersonReport {
    
    // DO NOT CHANGE THE ACCESS MODIFIERS NAYWHERE
    // I WILL TAKE A LOT OF POINT OFF IF YOU DO
   
    // THIS CLASS IS OK
    
    //----------------------------------------
    // constructor 
    //----------------------------------------  

    public FinancialReport(ArrayList<String> header, Map<String, Object> reportData) {

        super(header, reportData);
        System.out.println("");
    }

   
    
}
